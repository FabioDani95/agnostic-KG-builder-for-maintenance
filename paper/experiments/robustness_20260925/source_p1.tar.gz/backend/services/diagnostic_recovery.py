"""Bounded recovery planning; no rewriting, inference or automatic approval."""
from __future__ import annotations

from typing import Any


def recovery_packets(report: dict[str, Any], pages: list[dict], windows: list[dict], *, limit: int) -> list[tuple[list[dict], list[dict]]]:
    """Re-read smaller source packets after truncation or record validation failure.

    Refusals are never retried. A valid sibling is retained by the caller.
    Evidence/semantic uncertainty is left to the separate selective escalation
    policy; this planner only recovers incomplete or schema-invalid responses.
    """
    if limit <= 0 or report.get("refusal"):
        return []
    invalid = [entry for entry in report.get("records", []) if entry.get("accounting_state") == "record_schema_invalid"]
    truncated = report.get("finish_reason") == "length"
    if not truncated and not invalid:
        return []
    target_windows = windows
    target_pages = pages
    if invalid and not truncated:
        ids = {str(entry.get("record_window_id") or "") for entry in invalid}
        selected = [window for window in windows if window.get("window_id") in ids]
        if selected:
            target_windows = selected
        numbers: set[int] = set()
        def visit(value):
            if isinstance(value, dict):
                if isinstance(value.get("source_page"), int):
                    numbers.add(value["source_page"])
                for item in value.values():
                    visit(item)
            elif isinstance(value, list):
                for item in value:
                    visit(item)
        for entry in invalid:
            visit(entry.get("invalid_payload"))
        if numbers:
            target_pages = [page for page in pages if page["page_number"] in numbers]
    if target_windows:
        groups = [target_windows]
        if len(target_windows) > 1 and limit > 1:
            midpoint = (len(target_windows) + 1) // 2
            groups = [target_windows[:midpoint], target_windows[midpoint:]]
        return [([p for p in target_pages if p["page_number"] in {n for w in group for n in w["page_numbers"]}], group) for group in groups][:limit]
    if len(target_pages) > 1 and limit > 1:
        midpoint = (len(target_pages) + 1) // 2
        # Include a page of continuation context; no information is dropped.
        # Two-page packets cannot shrink with overlap, but retry is still bound.
        return [(target_pages[:midpoint + (len(target_pages) > 2)], []), (target_pages[midpoint:], [])]
    return [(target_pages, [])] if target_pages else []
