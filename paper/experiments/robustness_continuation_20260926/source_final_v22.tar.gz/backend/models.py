from enum import Enum
from typing import Any

from pydantic import BaseModel, Field

from backend.config import DEFAULT_MODEL_NAME


class Severity(str, Enum):
    LOW = "Low"
    MEDIUM = "Medium"
    HIGH = "High"
    CRITICAL = "Critical"


class Symptom(BaseModel):
    symptom_id: str
    name: str
    description: str
    severity: Severity
    evidence_page: int = 0


class FailureMode(BaseModel):
    failure_mode_id: str
    name: str
    description: str
    material_context: str
    linked_symptom_id: str
    evidence_page: int = 0
    # Codes of ErrorCode nodes wired to this failure via INDICATES, so the
    # alarm-code chain survives the projection into triplets.
    error_codes: list[str] = Field(default_factory=list)


class CorrectiveAction(BaseModel):
    action_id: str
    name: str
    description: str
    instruction_text: str
    source_type: str
    source_title: str
    source_page: int
    linked_failure_mode_id: str
    # "procedure" (on-site operational remedy) or "escalation" (contact the
    # maker/dealer/service). Lets the downstream agent present the two differently.
    action_kind: str = "procedure"


class Triplet(BaseModel):
    symptom: Symptom
    failure_modes: list[FailureMode]
    corrective_actions: list[CorrectiveAction]
    # Union of the error codes carried by this triplet's failure modes.
    error_codes: list[str] = Field(default_factory=list)


class ExtractionResult(BaseModel):
    triplets: list[Triplet]
    raw_symptom_table: str
    raw_failure_mode_table: str
    raw_corrective_action_table: str


class UploadResponse(BaseModel):
    pdf_id: str
    filename: str
    page_count: int
    run_id: str


class ExtractRequest(BaseModel):
    pdf_id: str
    source_type: str
    source_title: str
    model_name: str = DEFAULT_MODEL_NAME
    pages_to_keep: list[int] | None = None
    target_language: str = "en"
    # Optional operator hint about what to look for (used by chat re-extraction).
    hint: str = ""
    # Skip the graph-projection shortcut and always run LLM extraction.
    # Targeted re-extraction needs this: projection ignores the page range.
    force_llm: bool = False


class GenerateJsonRequest(BaseModel):
    pdf_id: str | None = None
    validated_triplets: list[Triplet]
    target_language: str = "en"


class OntologyPropertyDefinition(BaseModel):
    name: str
    type: str
    required: bool = False
    unique: bool = False
    items: str | None = None


class OntologyNodeDefinition(BaseModel):
    name: str
    description: str
    properties: list[OntologyPropertyDefinition]


class OntologyRelationDefinition(BaseModel):
    name: str
    domain: str
    range: str
    description: str


class OntologySchemaDefinition(BaseModel):
    ontology_name: str
    version: str
    language: str
    description: str
    design_principles: list[str] = Field(default_factory=list)
    nodes: list[OntologyNodeDefinition]
    relations: list[OntologyRelationDefinition]


class OntologyEvidence(BaseModel):
    source_page: int = 0
    source_reference: str = ""
    quote: str = ""
    source_anchor: str = ""


class OntologyRelationInstance(BaseModel):
    name: str
    from_type: str
    from_id: str
    to_type: str
    to_id: str
    evidence: list[OntologyEvidence] = Field(default_factory=list)
    # Intermediate-only occurrence identity.  The PDF adapter uses it to keep
    # semantically shared nodes from creating a Cartesian product of branches.
    # It is provenance metadata, not an ontology relation property.
    branch_lineage_id: str = ""


class OntologyInstance(BaseModel):
    ontology_name: str
    version: str
    language: str
    source_type: str
    source_title: str
    nodes: dict[str, list[dict[str, Any]]] = Field(default_factory=dict)
    relations: list[OntologyRelationInstance] = Field(default_factory=list)


class ExportOntologyMetadata(BaseModel):
    product_name: str
    product_short_name: str
    product_type: str
    domain_topics: list[str]
    version: str = ""
    file_version: str = ""
    total_nodes: int = 0
    total_relationships: int = 0


class ExportOntologyRelationship(BaseModel):
    type: str
    from_id: str
    to_id: str
    evidence: list[OntologyEvidence] = Field(default_factory=list)
    branch_lineage_id: str = ""


class ExportOntologyInstance(BaseModel):
    metadata: ExportOntologyMetadata
    nodes: dict[str, list[dict[str, Any]]] = Field(default_factory=dict)
    relationships: list[ExportOntologyRelationship] = Field(default_factory=list)


class PipelineIssue(BaseModel):
    severity: str
    code: str
    message: str
    target_type: str = ""
    target_id: str = ""
    property_name: str = ""
    fix_hint: str = ""


class HumanRequiredField(BaseModel):
    field_key: str
    prompt: str
    target_type: str
    target_id: str
    property_name: str
    reason: str
    expected_type: str = "string"
    suggested_value: str = ""
    allowed_values: list[str] = Field(default_factory=list)


class HumanBindingAnswer(BaseModel):
    field_key: str
    value: str


class OntologyDraftRequest(BaseModel):
    pdf_id: str
    source_type: str
    source_title: str
    model_name: str = DEFAULT_MODEL_NAME
    reasoning_effort: str | None = None
    pages_to_keep: list[int] | None = None
    target_language: str = "en"


class GraphIssue(BaseModel):
    issue_type: str  # orphan | missing_relation | broken_chain | cycle
    affected_nodes: list[str] = Field(default_factory=list)
    description: str
    suggested_fix: str = ""
    auto_fixable: bool = False


class SuggestedRelation(BaseModel):
    relation_name: str
    from_type: str
    from_id: str
    from_label: str
    to_type: str
    to_id: str
    to_label: str
    confidence: float
    rationale: str = ""


class ConfidenceEntry(BaseModel):
    """Per-node confidence record produced by the Step 3 scoring layer.

    Kept separate from OntologyInstance.nodes (which remain opaque dicts) so that
    scores can be attached/updated without touching the core ontology payload.
    """

    node_type: str
    node_id: str
    score: float
    classification: str  # auto_approve | human_review | auto_reject
    signals: dict[str, float] = Field(default_factory=dict)
    penalties: dict[str, float] = Field(default_factory=dict)
    reasons: list[str] = Field(default_factory=list)


class ConfidenceReport(BaseModel):
    entries: list[ConfidenceEntry] = Field(default_factory=list)
    theta_high: float = 0.0
    theta_low: float = 0.0
    auto_reject_enabled: bool = False
    counts: dict[str, int] = Field(default_factory=dict)  # classification -> count


class OntologyPipelineResponse(BaseModel):
    status: str
    ontology: OntologyInstance
    semantic_issues: list[PipelineIssue] = Field(default_factory=list)
    schema_issues: list[PipelineIssue] = Field(default_factory=list)
    human_required_fields: list[HumanRequiredField] = Field(default_factory=list)
    is_schema_compliant: bool = False
    is_ready_for_human_review: bool = False
    retry_count: int = 0
    graph_issues: list[GraphIssue] = Field(default_factory=list)
    suggested_relations: list[SuggestedRelation] = Field(default_factory=list)
    confidence_report: ConfidenceReport | None = None
    # Record-level accounting for the typed diagnostic extraction contract.
    # Kept outside OntologyInstance so lineage, incomplete candidates and model
    # diagnostics never become part of the configured domain ontology.
    diagnostic_contract_report: dict[str, Any] = Field(default_factory=dict)
    resolution_completion_report: dict[str, Any] = Field(default_factory=dict)
    # Run-level, deterministic cross-chunk consolidation metadata.  This is
    # intentionally outside OntologyInstance so the configured ontology stays
    # unchanged.
    canonicalization_report: dict[str, Any] = Field(default_factory=dict)
    # Fase A4 — the unified "red zone" the operator must review: open structural
    # gaps + low-confidence nodes + advisory issues, priority-ordered.
    review_queue: list[dict[str, Any]] = Field(default_factory=list)
    review_summary: dict[str, Any] = Field(default_factory=dict)


# ─── Cut Plan Models ───


class PageRange(BaseModel):
    start: int  # physical page number (1-based)
    end: int    # physical page number (1-based, inclusive)


class TocEntry(BaseModel):
    title: str
    manual_page: int  # page number as printed in the manual


class StructuredToc(BaseModel):
    entries: list[TocEntry]
    toc_start_page: int  # absolute PDF page where ToC starts
    toc_end_page: int    # absolute PDF page where ToC ends


class SectionInfo(BaseModel):
    name: str
    page_range: PageRange                      # absolute PDF pages
    manual_page_range: PageRange | None = None  # manual pages (for display)
    source: str                                # "rule" | "llm" | "keyword" | "user"
    keyword_matches: list[str] = Field(default_factory=list)
    reasoning: str = ""


class ProductInfo(BaseModel):
    product_name: str = ""
    product_short_name: str = ""
    brand: str = ""
    model: str = ""
    asset_id: str = ""
    asset_type: str = ""
    document_type: str = ""
    language: str = ""
    page_count: int = 0


class CutPlan(BaseModel):
    pdf_id: str
    total_pages: int
    sections: list[SectionInfo]
    pages_to_keep: list[int]
    page_offset: int = 0
    # How page_offset was determined (source, confidence, votes) when
    # autodetected; None for explicit overrides.
    page_offset_detection: dict | None = None
    toc: StructuredToc | None = None
    skipped: bool = False
    product_info: ProductInfo | None = None


class CutPlanRequest(BaseModel):
    pdf_id: str
    model_name: str = DEFAULT_MODEL_NAME
    reasoning_effort: str | None = None
    # Workspace/G3 runs already have an operator-confirmed Asset.  Keep legacy
    # standalone callers on discovery by default, but let workspace callers
    # explicitly prevent the PDF from redefining that canonical identity.
    discover_asset_identity: bool = True
    # None (default) → the printed-page offset is autodetected from the
    # document; an explicit integer (including 0) is a manual override.
    page_offset: int | None = None


class CutPlanApprovalSection(BaseModel):
    """Lightweight section info sent back from the frontend during approve."""
    name: str
    page_range: PageRange
    source: str = ""


class CutPlanApproval(BaseModel):
    pdf_id: str
    pages_to_keep: list[int]
    page_offset: int = 0
    sections: list[CutPlanApprovalSection] = Field(default_factory=list)


class LoadManualRequest(BaseModel):
    filename: str
