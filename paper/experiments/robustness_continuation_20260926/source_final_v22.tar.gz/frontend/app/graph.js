(function () {
  "use strict";
  const root = window.KGFoundation = window.KGFoundation || {};
  const state = root.state;
  const esc = root.escapeHtml;
  const t = root.t;
  const n = root.n;

  let cercaTimer = 0;
  let explorer = null;

  const wsId = () => state.workspace.workspace.workspace_id;
  const vistaFonte = () => {
    if (!state.graph) return null;
    const attiva = root.fonteAttiva();
    if (!attiva) return null;
    return state.graph.sources.find((v) => v.source_id === attiva.source_id) || null;
  };

  /**
   * Quale elemento una lacuna riguarda davvero.
   *
   * Il motore attacca le lacune alle righe, non ai nodi. Far ereditare la
   * lacuna a ogni nodo nato da quella riga marcava anche la macchina — che
   * compare in tutte le righe — e il sintomo, quando a mancare era l'azione
   * della causa. Qui una lacuna tocca solo i tipi che ne sono l'oggetto:
   * quello che resta senza controparte.
   *
   * Macchina e componente non compaiono mai: sono sempre dichiarati, non sono
   * mai il pezzo mancante di una catena diagnostica.
   */
  const TIPI_TOCCATI = {
    missing_failure_mode: ["Symptom", "ErrorCode"],
    missing_diagnostic_indicator: ["FailureMode"],
    missing_corrective_action: ["FailureMode"],
    /* Gli abbinamenti ambigui non possono più nascere con una colonna per
       ruolo, ma la rete di sicurezza del motore resta: se ricompaiono, a
       restare senza collegamento sono i due estremi. */
    ambiguous_symptom_cause_pairing: ["Symptom", "FailureMode"],
    ambiguous_cause_component_pairing: ["FailureMode", "Component"],
    ambiguous_cause_action_pairing: ["FailureMode", "CorrectiveAction"],
    ambiguous_error_cause_pairing: ["ErrorCode", "FailureMode"],
  };

  /* ------------------------------------------------------------- modello -- */
  const costruisciModello = (grafo) => {
    const nodiPerId = new Map(grafo.nodes.map((nodo) => [nodo.node_id, nodo]));
    const evidenzePerId = new Map(grafo.evidence.map((voce) => [voce.evidence_id, voce]));
    const grado = new Map();
    const legamiPerNodo = new Map();
    grafo.relations.forEach((legame) => {
      [legame.from_id, legame.to_id].forEach((id) => {
        grado.set(id, (grado.get(id) || 0) + 1);
        if (!legamiPerNodo.has(id)) legamiPerNodo.set(id, []);
        legamiPerNodo.get(id).push(legame);
      });
    });

    /* Una lacuna è attaccata a un'evidenza; un nodo eredita le lacune delle
       righe che l'hanno prodotto, così "cosa blocca questo nodo" ha risposta. */
    const lacunePerEvidenza = new Map();
    (grafo.knowledge_gaps || []).forEach((lacuna) => {
      (lacuna.evidence_ids || []).forEach((id) => {
        if (!lacunePerEvidenza.has(id)) lacunePerEvidenza.set(id, []);
        lacunePerEvidenza.get(id).push(lacuna);
      });
    });
    const lacunePerNodo = new Map();
    (grafo.knowledge_gaps || []).forEach((lacuna) => {
      if (!lacuna.target_id || !nodiPerId.has(lacuna.target_id)) return;
      if (!lacunePerNodo.has(lacuna.target_id)) lacunePerNodo.set(lacuna.target_id, []);
      lacunePerNodo.get(lacuna.target_id).push(lacuna);
    });
    grafo.nodes.forEach((nodo) => {
      const lacune = [...(lacunePerNodo.get(nodo.node_id) || [])];
      nodo.evidence_ids.forEach((id) => (lacunePerEvidenza.get(id) || []).forEach((lacuna) => {
        if (!TIPI_TOCCATI[lacuna.code]) return;
        if (!TIPI_TOCCATI[lacuna.code].includes(nodo.node_type)) return;
        if (!lacune.includes(lacuna)) lacune.push(lacuna);
      }));
      if (lacune.length) lacunePerNodo.set(nodo.node_id, lacune);
    });
    const difettiPerNodo = new Map();
    ((grafo.validation || {}).issues || []).forEach((difetto) => {
      if (!difetto.node_id) return;
      if (!difettiPerNodo.has(difetto.node_id)) difettiPerNodo.set(difetto.node_id, []);
      difettiPerNodo.get(difetto.node_id).push(difetto);
    });

    /* — filtri: valgono su tutte le viste insieme, mappa e tabelle — */
    const cerca = String(state.filters.query || "").trim().toLocaleLowerCase();
    let visibili = grafo.nodes.filter((nodo) => {
      if (state.filters.nodeType !== "all" && nodo.node_type !== state.filters.nodeType) return false;
      if (state.filters.onlyGaps && !lacunePerNodo.has(nodo.node_id) && !difettiPerNodo.has(nodo.node_id)) return false;
      if (cerca && !nodo.label.toLocaleLowerCase().includes(cerca)) return false;
      return true;
    });
    if (state.filters.relationType !== "all") {
      const estremi = new Set();
      grafo.relations.filter((l) => l.relation_type === state.filters.relationType)
        .forEach((l) => { estremi.add(l.from_id); estremi.add(l.to_id); });
      visibili = visibili.filter((nodo) => estremi.has(nodo.node_id));
    }
    if (state.filters.focus && state.selection.kind === "node" && nodiPerId.has(state.selection.id)) {
      const tieni = new Set([state.selection.id]);
      (legamiPerNodo.get(state.selection.id) || []).forEach((l) => { tieni.add(l.from_id); tieni.add(l.to_id); });
      visibili = visibili.filter((nodo) => tieni.has(nodo.node_id));
    }

    const idVisibili = new Set(visibili.map((nodo) => nodo.node_id));
    const legami = grafo.relations.filter((l) => (
      idVisibili.has(l.from_id) && idVisibili.has(l.to_id)
      && (state.filters.relationType === "all" || l.relation_type === state.filters.relationType)
    ));

    return {
      grafo, nodi: visibili, legami, nodiPerId, evidenzePerId, legamiPerNodo, grado,
      lacunePerNodo, lacunePerEvidenza, difettiPerNodo,
      nascosti: grafo.nodes.length - visibili.length,
      /* Un filtro che non può togliere niente non è un filtro: chi lo offre
         promette una selezione che non esiste. Si calcola qui, una volta, e
         lo leggono tutte le strisce che mostrano quella spunta. */
      conLacune: grafo.nodes.some((nodo) => (
        lacunePerNodo.has(nodo.node_id) || difettiPerNodo.has(nodo.node_id)
      )),
    };
  };

  const proiettaGrafo = (grafo) => {
    const proiezioni = grafo.projections || {};
    const scelta = proiezioni[state.graphProjection]
      || proiezioni.diagnostic || proiezioni.canonical;
    if (!scelta) return grafo;
    const nodi = new Set(scelta.node_ids || []);
    const relazioni = new Set(scelta.relation_ids || []);
    return {
      ...grafo,
      nodes: grafo.nodes.filter((nodo) => nodi.has(nodo.node_id)),
      relations: grafo.relations.filter((relazione) => relazioni.has(relazione.relation_id)),
    };
  };

  const modelloDi = (vista) => (vista && vista.subgraph
    ? costruisciModello(proiettaGrafo(vista.subgraph)) : null);

  const intervalliPagine = (pagine) => {
    const ordinate = [...new Set((pagine || []).map(Number).filter(Number.isInteger))].sort((a, b) => a - b);
    const intervalli = [];
    let inizio = null;
    let fine = null;
    ordinate.forEach((pagina) => {
      if (inizio === null) { inizio = pagina; fine = pagina; return; }
      if (pagina === fine + 1) { fine = pagina; return; }
      intervalli.push(inizio === fine ? `${inizio}` : `${inizio}–${fine}`);
      inizio = pagina;
      fine = pagina;
    });
    if (inizio !== null) intervalli.push(inizio === fine ? `${inizio}` : `${inizio}–${fine}`);
    return intervalli.join(", ");
  };

  const ambitoPdf = (grafo) => {
    const ambito = grafo && grafo.pdf_extraction_scope;
    if (!ambito) return "";
    const selezionate = (ambito.selected_pages || []).length;
    const escluse = (ambito.unselected_pages || []).length;
    const diagnostiche = (ambito.diagnostic_pages || []).length;
    const strutturali = (ambito.structural_pages || []).length;
    return `<div class="intestazione-lavoro" data-pdf-scope>
      <p><strong>${esc(t("gr.pdfAmbitoTitolo"))}</strong> ${esc(t("gr.pdfAmbitoTesto", {
        n: selezionate,
        t: ambito.total_pages,
        r: intervalliPagine(ambito.selected_pages),
        e: escluse,
      }))} ${diagnostiche || strutturali ? esc(t("gr.pdfRuoli", { d: diagnostiche, s: strutturali })) : ""}</p>
    </div>`;
  };

  const chipAmbitoPdf = (grafo) => {
    const ambito = grafo && grafo.pdf_extraction_scope;
    if (!ambito) return "";
    return `<span class="chip"><b>${(ambito.selected_pages || []).length}/${ambito.total_pages}</b> ${esc(t("gr.pagine"))}</span>`;
  };

  const numeroKpi = (valore, cifre = 0) => new Intl.NumberFormat(
    root.lingua() === "en" ? "en-GB" : "it-IT",
    { maximumFractionDigits: cifre, minimumFractionDigits: cifre }
  ).format(Number(valore || 0));

  const durataKpi = (secondi) => {
    const valore = Math.max(0, Number(secondi || 0));
    if (valore < 60) return `${numeroKpi(valore, valore < 10 ? 1 : 0)} s`;
    const minuti = Math.floor(valore / 60);
    const resto = Math.round(valore % 60);
    return `${minuti} min ${resto} s`;
  };

  const costoKpi = (valore) => {
    const costo = Math.max(0, Number(valore || 0));
    const cifre = costo > 0 && costo < 0.01 ? 4 : 2;
    return new Intl.NumberFormat(
      root.lingua() === "en" ? "en-US" : "it-IT",
      { style: "currency", currency: "USD", minimumFractionDigits: cifre, maximumFractionDigits: cifre }
    ).format(costo);
  };

  const kpiPdf = (grafo) => {
    const metriche = grafo && grafo.generation_metrics;
    if (!metriche) return "";
    const modelli = (metriche.models || []).join(", ") || "—";
    const ontology = (metriche.stages || {}).ontology || {};
    const chunks = Number((ontology.details || {}).chunk_count || 0);
    const modalita = metriche.execution_mode === "mock" ? t("gr.kpiMock") : t("gr.kpiReale");
    return `<section class="pdf-kpi" data-pdf-kpi aria-label="${esc(t("gr.kpiTitolo"))}">
      <div class="pdf-kpi-testa"><strong>${esc(t("gr.kpiTitolo"))}</strong><span>${esc(modalita)}</span></div>
      <div class="pdf-kpi-griglia">
        <div><span>${esc(t("gr.kpiTempo"))}</span><b>${esc(durataKpi(metriche.duration_seconds))}</b></div>
        <div><span>${esc(t("gr.kpiCosto"))}</span><b>${esc(costoKpi(metriche.estimated_cost_usd))}</b></div>
        <div><span>${esc(t("gr.kpiToken"))}</span><b>${esc(numeroKpi(metriche.total_tokens))}</b></div>
        <div><span>${esc(t("gr.kpiChiamate"))}</span><b>${esc(numeroKpi(metriche.llm_calls))}</b></div>
      </div>
      <p>${esc(t("gr.kpiNota", { modelli, chunks }))}</p>
    </section>`;
  };

  const riepilogoPdf = (grafo) => `${ambitoPdf(grafo)}${kpiPdf(grafo)}`;

  /* La spunta delle lacune, uguale nelle due strisce che la offrono. Resta
     attivabile solo se qualcosa può togliere, e resta togliibile sempre: chi
     l'ha accesa deve poterla spegnere anche dopo aver corretto l'ultima. */
  root.spuntaLacune = function spuntaLacune(modello) {
    const spenta = !modello.conLacune && !state.filters.onlyGaps;
    return `<label class="spunta ${spenta ? "spenta" : ""}"
      ${spenta ? `title="${esc(t("gr.nienteLacune"))}"` : ""}>
      <input type="checkbox" data-filtro="onlyGaps" ${state.filters.onlyGaps ? "checked" : ""}
        ${spenta ? "disabled" : ""}>${esc(t("gr.soloLacune"))}</label>`;
  };

  /* --------------------------------------------------------------- rete -- */
  const carica = async () => {
    if (!state.workspace) return;
    state.graphLoading = true;
    state.graphError = "";
    try {
      state.graph = await root.api(`/api/workspaces/${encodeURIComponent(wsId())}/g3/subgraphs`);
    } catch (errore) {
      state.graphError = errore.message;
    } finally {
      state.graphLoading = false;
    }
    /* Il numero accanto a una fonte nel menu è lo stesso in ogni fase, e viene
       dalla preparazione: qui va letta anche se questa fase non la usa, o
       arrivando dritti al grafo quel numero mancherebbe. È una lettura, non
       una preparazione: non cambia niente. */
    if (!state.structure && root.leggiPreparazione) await root.leggiPreparazione();
  };

  const esegui = async (azione) => {
    state.graphBusy = true;
    state.graphError = "";
    root.render({ regioni: ["decisione"] });
    try {
      state.graph = await azione();
      if (root.loadJourney) await root.loadJourney();
    } catch (errore) { state.graphError = errore.message; }
    finally { state.graphBusy = false; root.render(); }
  };

  /* -------------------------------------------------------------- viste -- */
  const VISTE = [
    { id: "mappa", chiave: "gr.vista.mappa" },
    { id: "catene", chiave: "gr.vista.catene" },
    { id: "elementi", chiave: "gr.vista.elementi" },
    { id: "collegamenti", chiave: "gr.vista.collegamenti" },
    { id: "righe", chiave: "gr.vista.righe" },
    { id: "manca", chiave: "gr.vista.manca" },
    { id: "revisione", chiave: "Revisione dei record" },
  ];

  const barra = (modello) => {
    const pdf = modello.grafo.source_kind === "pdf";
    const tipiRel = [...new Set(modello.grafo.relations.map((l) => l.relation_type))];
    const conteggi = {
      elementi: modello.grafo.nodes.length,
      collegamenti: modello.grafo.relations.length,
      righe: modello.grafo.evidence.length,
      manca: (modello.grafo.knowledge_gaps || []).length
        + (((modello.grafo.validation || {}).issues) || []).length,
    };
    if (state.view === "revisione") return `<div class="barra"><div class="segmento" role="tablist" style="flex-wrap:wrap;max-width:100%">${VISTE.map((vista) => `<button type="button" class="tab" role="tab" data-vista="${vista.id}" aria-selected="${state.view === vista.id}">${esc(t(pdf && vista.id === "righe" ? "gr.vista.evidenze" : vista.chiave))}</button>`).join("")}</div></div>`;
    return `
      <div class="barra">
        <div class="segmento" role="tablist" style="flex-wrap:wrap;max-width:100%">
          ${VISTE.map((vista) => `<button type="button" class="tab" role="tab" data-vista="${vista.id}"
            aria-selected="${state.view === vista.id}">${esc(t(pdf && vista.id === "righe" ? "gr.vista.evidenze" : vista.chiave))}${conteggi[vista.id] == null ? "" : ` ${conteggi[vista.id]}`}</button>`).join("")}
        </div>
        <span class="barra-spazio"></span>
        <div class="barra-gruppo">
          ${Object.keys(modello.grafo.projections || {}).length ? `
          <label class="solo-lettori" for="kg-proiezione">${esc(t("gr.proiezione"))}</label>
          <select id="kg-proiezione" data-proiezione>
            ${["diagnostic", "structural", "canonical"].filter((id) => modello.grafo.projections[id])
              .map((id) => `<option value="${id}" ${state.graphProjection === id ? "selected" : ""}>${esc(t(`gr.proiezione.${id}`))}</option>`).join("")}
          </select>` : ""}
          <label class="solo-lettori" for="kg-cerca">${esc(t("gr.cerca"))}</label>
          <input id="kg-cerca" type="search" data-cerca placeholder="${esc(t("gr.cerca"))}"
            value="${esc(state.filters.query)}">
          <label class="solo-lettori" for="kg-tipo">${esc(t("gr.tipoElemento"))}</label>
          <select id="kg-tipo" data-filtro="nodeType">
            <option value="all">${esc(t("gr.tuttiTipi"))}</option>
            ${root.ordineTipi.map((tipo) => `<option value="${tipo}" ${state.filters.nodeType === tipo ? "selected" : ""}>${esc(root.etichettaTipoPl(tipo))}</option>`).join("")}
          </select>
          <label class="solo-lettori" for="kg-rel">${esc(t("gr.tipoCollegamento"))}</label>
          <select id="kg-rel" data-filtro="relationType">
            <option value="all">${esc(t("gr.tuttiCollegamenti"))}</option>
            ${tipiRel.map((tipo) => `<option value="${tipo}" ${state.filters.relationType === tipo ? "selected" : ""}>${esc(root.etichettaRelazione(tipo))}</option>`).join("")}
          </select>
          ${root.spuntaLacune(modello)}
          <label class="spunta"><input type="checkbox" data-filtro="focus" ${state.filters.focus ? "checked" : ""}>${esc(t("gr.soloIntorno"))}</label>
        </div>
      </div>`;
  };

  const riassuntoFiltri = (modello) => (modello.nascosti
    ? `<p class="voce-meta" style="margin-bottom:12px">${esc(t("gr.nascosti", { n: modello.nascosti }))}
        <button type="button" class="btn quieto piccolo" data-azzera>${esc(t("gr.azzera"))}</button></p>`
    : "");

  /* Perché la mappa è vuota. «Nessun elemento corrisponde ai filtri» è vero
     anche quando l'unico filtro acceso non poteva corrispondere a niente: in
     quel caso la frase da dire è che lacune non ce ne sono. */
  const motivoVuoto = (modello) => {
    if (!modello.grafo.nodes.length) return t("gr.nienteElementi");
    if (state.filters.onlyGaps && !modello.conLacune) return t("gr.nienteLacune");
    return t("gr.nienteFiltriTesto");
  };

  const mappa = (modello) => {
    if (!modello.nodi.length) {
      return `<div class="lavoro-pad"><div class="vuoto">
        <strong>${esc(t("gr.nienteFiltri"))}</strong>
        <p>${esc(motivoVuoto(modello))}</p>
        ${modello.grafo.nodes.length ? `<button type="button" class="btn secondario" data-azzera>${esc(t("gr.azzera"))}</button>` : ""}
      </div></div>`;
    }
    const legenda = root.ordineTipi
      .filter((tipo) => modello.nodi.some((nodo) => nodo.node_type === tipo))
      .map((tipo) => `<span class="tipo-${tipo}"><i aria-hidden="true"></i>${esc(root.etichettaTipoPl(tipo))}</span>`)
      .join("");
    return `
      <div class="grafo" data-grafo>
        ${modello.nascosti ? `<div class="grafo-nascosti floating">
          <span>${esc(t("gr.nascosti", { n: modello.nascosti }))}</span>
          <button type="button" class="btn quieto piccolo" data-azzera>${esc(t("gr.azzera"))}</button>
        </div>` : ""}
        ${legenda ? `<div class="grafo-legenda floating">${legenda}</div>` : ""}
        <div class="grafo-comandi floating">
          <button type="button" class="btn quieto segno" data-zoom="meno" aria-label="${esc(t("gr.riduci"))}">−</button>
          <span class="grafo-zoom" data-zoom-valore>100%</span>
          <button type="button" class="btn quieto segno" data-zoom="piu" aria-label="${esc(t("gr.ingrandisci"))}">+</button>
          <button type="button" class="btn quieto piccolo" data-zoom="adatta">${esc(t("gr.adatta"))}</button>
          <button type="button" class="btn quieto piccolo" data-ridisponi title="${esc(t("gr.ridisponiTitolo"))}">${esc(t("gr.ridisponi"))}</button>
        </div>
      </div>`;
  };

  const tabellaElementi = (modello) => `
    <div class="lavoro-pad">
      ${riassuntoFiltri(modello)}
      <div class="tabella-wrap"><table class="tabella"><thead><tr>
        <th>${esc(t("gr.tipo"))}</th><th>${esc(t("gr.elemento"))}</th>
        <th class="num">${esc(t("gr.collegamentiCol"))}</th>
        <th class="num">${esc(t(modello.grafo.source_kind === "pdf" ? "gr.evidenzeOrigineCol" : "gr.righeOrigineCol"))}</th>
        <th>${esc(t("gr.statoCol"))}</th>
      </tr></thead><tbody>
        ${modello.nodi.length ? modello.nodi.map((nodo) => {
          const lacuna = modello.lacunePerNodo.has(nodo.node_id);
          const difetto = modello.difettiPerNodo.has(nodo.node_id);
          return `<tr data-clic data-scegli="nodo" data-id="${esc(nodo.node_id)}"
            aria-selected="${state.selection.kind === "node" && state.selection.id === nodo.node_id}">
            <td><span class="ruolo tipo-${esc(nodo.node_type)}"><i aria-hidden="true"></i>${esc(root.etichettaTipo(nodo.node_type))}</span></td>
            <td>${esc(nodo.label)}</td>
            <td class="num">${modello.grado.get(nodo.node_id) || 0}</td>
            <td class="num">${nodo.evidence_ids.length}</td>
            <td>${difetto ? `<span class="badge errore">${esc(t("gr.difetto"))}</span>`
              : lacuna ? `<span class="badge attesa">${esc(t("gr.lacuna"))}</span>`
              : `<span class="badge">${esc(t("gr.completo"))}</span>`}</td>
          </tr>`;
        }).join("") : `<tr><td colspan="5">${esc(t("gr.nienteElementiFiltri"))}</td></tr>`}
      </tbody></table></div>
    </div>`;

  const tabellaCollegamenti = (modello) => `
    <div class="lavoro-pad">
      ${riassuntoFiltri(modello)}
      <div class="tabella-wrap"><table class="tabella"><thead><tr>
        <th>${esc(t("gr.da"))}</th><th>${esc(t("gr.collegamento"))}</th><th>${esc(t("gr.a"))}</th>
        <th class="num">${esc(t(modello.grafo.source_kind === "pdf" ? "gr.evidenzeOrigineCol" : "gr.righeOrigineCol"))}</th>
      </tr></thead><tbody>
        ${modello.legami.length ? modello.legami.map((legame) => {
          const da = modello.nodiPerId.get(legame.from_id);
          const a = modello.nodiPerId.get(legame.to_id);
          return `<tr data-clic data-scegli="arco" data-id="${esc(legame.relation_id)}"
            aria-selected="${state.selection.kind === "relation" && state.selection.id === legame.relation_id}">
            <td>${esc(da ? da.label : "—")}</td>
            <td><span class="badge">${esc(root.etichettaRelazione(legame.relation_type))}</span></td>
            <td>${esc(a ? a.label : "—")}</td>
            <td class="num">${legame.evidence_ids.length}</td>
          </tr>`;
        }).join("") : `<tr><td colspan="4">${esc(t("gr.nienteCollegamentiFiltri"))}</td></tr>`}
      </tbody></table></div>
    </div>`;

  const listaRighe = (modello) => {
    const pdf = modello.grafo.source_kind === "pdf";
    return `
    <div class="lavoro-pad">
      <div class="gruppo-capo"><h3>${esc(t(pdf ? "gr.evidenzeTitolo" : "gr.righeTitolo"))}</h3><p>${esc(t(pdf ? "gr.evidenzeTesto" : "gr.righeTesto"))}</p></div>
      <div class="lista" style="margin-top:12px">
        ${modello.grafo.evidence.map((voce) => {
          const lacune = modello.lacunePerEvidenza.get(voce.evidence_id) || [];
          return `<button type="button" class="voce" data-scegli="evidenza" data-id="${esc(voce.evidence_id)}"
            aria-selected="${state.selection.kind === "evidence" && state.selection.id === voce.evidence_id}">
            <span class="voce-capo"><strong>${esc(root.descriviLocator(voce.locator))}</strong>
              ${lacune.length ? `<span class="badge attesa">${esc(n(lacune.length, "isp.lacune"))}</span>` : ""}</span>
            <span class="voce-testo">${esc(voce.excerpt || t(pdf ? "gr.evidenzaSenzaTesto" : "gr.rigaSenzaTesto"))}</span>
          </button>`;
        }).join("")}
      </div>
    </div>`;
  };

  const dettagliDiagnostici = (modello) => {
    const records = modello.grafo.diagnostic_records || [];
    if (!records.length) return "";
    const elenco = (title, values) => values.length
      ? `<div class="voce-testo"><strong>${esc(t(title))}</strong><ol>${values.map((v) => `<li>${esc(v)}</li>`).join("")}</ol></div>` : "";
    return `<section class="gruppo lavoro-pad"><div class="gruppo-capo"><h3>${esc(t("gr.recordTitolo"))}</h3>
      <p>${esc(t("gr.recordTesto"))}</p></div><div class="lista">${records.map((item) => {
        const record = item.record;
        const title = (record.indicators || []).map((v) => v.code ? `${v.code}: ${v.name}` : v.name).join(" · ");
        const steps = record.inspection_steps || [];
        const conditions = record.conditions || [];
        const evidence = [...conditions.flatMap((v) => v.claim_evidence || []), ...steps.flatMap((v) => v.claim_evidence || [])];
        const seen = new Set();
        const links = evidence.filter((v) => { const key = `${v.evidence_id}:${v.quote}`; if (seen.has(key)) return false; seen.add(key); return true; });
        return `<details class="voce"><summary><strong>${esc(title)}</strong> · ${esc(t(item.disposition === "gap" && !item.review_required ? "gr.recordFonteVerificata" : `gr.recordStato.${item.disposition}`))}</summary>
          ${record.failure ? `<p class="voce-testo">${esc(record.failure.name)}</p>` : ""}
          ${elenco("gr.recordCondizioni", conditions.map((v) => `${v.text} (${t(`gr.recordTarget.${v.applies_to}`)}${v.step_index === null ? "" : ` ${v.step_index + 1}`})`))}
          ${elenco("gr.recordIspezioni", steps.map((v) => v.instruction_text))}
          ${elenco("gr.recordAzioni", (record.actions || []).map((v) => v.instruction_text))}
          ${(record.procedure_context || []).length ? `<details><summary>Contesto sorgente della procedura: prerequisiti e alternative</summary><p>Ordine della fonte disponibile; il percorso tra le alternative richiede verifica.</p>${record.procedure_context.map((v) => `<p><strong>Pagina ${v.source_page}</strong> ${esc(v.quote)}</p>`).join("")}</details>` : ""}
          ${links.map((v) => `<button type="button" class="voce" data-scegli="evidenza" data-id="${esc(v.evidence_id)}"><span class="voce-meta">${esc(t("gr.recordPagina"))} ${v.source_page}</span><span class="voce-testo">${esc(v.quote)}</span></button>`).join("")}
        </details>`;
      }).join("")}</div></section>`;
  };

  /** Catene diagnostiche: una voce per causa, con quello che le righe provano. */
  const catene = (modello) => {
    const cause = modello.grafo.nodes.filter((nodo) => nodo.node_type === "FailureMode");
    if (!cause.length) {
      return `<div class="lavoro-pad"><div class="vuoto">
        <strong>${esc(t("gr.nienteCatene"))}</strong><p>${esc(t("gr.nienteCateneTesto"))}</p></div></div>`;
    }
    const passo = (nodo) => `<button type="button" class="catena-passo tipo-${esc(nodo.node_type)}"
      data-scegli="nodo" data-id="${esc(nodo.node_id)}"><i aria-hidden="true"></i><span>${esc(nodo.label)}</span></button>`;
    const freccia = '<span class="catena-freccia" aria-hidden="true">→</span>';

    const voci = cause.flatMap((causa) => root.catenePerCausa(modello, causa)).map((catena) => {
      const { causa, indizi, azioni, componenti } = catena;
      const manca = [];
      if (!indizi.length) manca.push(t("gr.senzaSintomo"));
      if (!azioni.length) manca.push(t("gr.senzaAzione"));
      return `
        <div class="voce">
          ${root.condizioniCatena(catena)}
          <div class="catena">
            ${indizi.length ? indizi.map(passo).join(freccia) : `<span class="catena-passo">${esc(t("gr.origineNonDichiarata"))}</span>`}
            ${freccia}${passo(causa)}${freccia}
            ${azioni.length ? azioni.map(passo).join('<span class="catena-freccia" aria-hidden="true">·</span>') : `<span class="catena-passo">${esc(t("gr.azioneNonDichiarata"))}</span>`}
          </div>
          ${componenti.length ? `<span class="voce-meta">${esc(t("gr.interessa", { n: componenti.map((c) => c.label).join(" · ") }))}</span>` : ""}
          ${manca.length ? `<span class="voce-meta">${esc(t("gr.catenaIncompleta", { n: manca.join(" · ") }))}</span>` : ""}
        </div>`;
    }).join("");

    return `<div class="lavoro-pad">
      <div class="gruppo-capo"><h3>${esc(t("gr.catenaTitolo"))}</h3><p>${esc(t("gr.catenaTesto"))}</p></div>
      <div class="lista" style="margin-top:12px">${voci}</div></div>`;
  };

  /** Le due classi che bloccano, affiancate ma mai mescolate. */
  const cosaManca = (modello) => {
    const lacune = modello.grafo.knowledge_gaps || [];
    const difetti = ((modello.grafo.validation || {}).issues) || [];
    if (!lacune.length && !difetti.length) {
      return `<div class="lavoro-pad"><div class="vuoto">
        <strong>${esc(t("gr.nienteBlocca"))}</strong><p>${esc(t("gr.nienteBloccaTesto"))}</p></div></div>`;
    }
    return `<div class="lavoro-pad">
        ${lacune.length ? `<section class="gruppo">
        <div class="gruppo-capo"><h3>${esc(t("gr.lacuneTitolo", { n: lacune.length }))}</h3>
          <p>${esc(t("gr.lacuneTesto"))}</p></div>
        <div class="lista">${lacune.map((lacuna) => {
          const id = (lacuna.evidence_ids || [])[0];
          const evidenza = id ? modello.evidenzePerId.get(id) : null;
          const bersaglio = lacuna.target_id && modello.nodiPerId.get(lacuna.target_id);
          const scelta = bersaglio
            ? `data-scegli="nodo" data-id="${esc(lacuna.target_id)}"`
            : (evidenza ? `data-scegli="evidenza" data-id="${esc(id)}"` : "");
          return `<button type="button" class="voce" ${scelta}>
            <span class="voce-capo"><span class="badge attesa"><span class="punto" aria-hidden="true"></span>${esc(t("gr.lacuna"))}</span>
              <strong>${esc(root.titoloLacuna(lacuna.code))}</strong></span>
            <span class="voce-testo">${esc(lacuna.message)}</span>
            ${evidenza ? `<span class="voce-meta">${esc(root.descriviLocator(evidenza.locator))}</span>` : ""}
          </button>`;
        }).join("")}</div></section>` : ""}
      ${difetti.length ? `<section class="gruppo">
        <div class="gruppo-capo"><h3>${esc(t("gr.difettiTitolo", { n: difetti.length }))}</h3>
          <p>${esc(t("gr.difettiTesto"))}</p></div>
        <div class="lista">${difetti.map((difetto) => `
          <button type="button" class="voce" ${difetto.node_id ? `data-scegli="nodo" data-id="${esc(difetto.node_id)}"` : ""}>
            <span class="voce-capo"><span class="badge errore"><span class="punto" aria-hidden="true"></span>${esc(t("gr.difetto"))}</span>
              <strong>${esc(root.titoloDifetto(difetto.code))}</strong></span>
            <span class="voce-testo">${esc(difetto.message)}</span>
          </button>`).join("")}</div></section>` : ""}
    </div>`;
  };

  const confronto = () => {
    const barriera = state.graph.merge_barrier;
    const trovate = barriera.exact_matches || [];
    const pronto = barriera.state === "ready";
    return `<div class="lavoro-pad">
      <div class="gruppo-capo"><h3>${esc(t("gr.confronto"))}</h3><p>${esc(t("gr.confrontoTesto"))}</p></div>
      <div class="nota ${pronto ? "info" : "attesa"}" style="margin-top:12px">
        <span class="segno" aria-hidden="true">${pronto ? "i" : "?"}</span>
        <strong>${esc(pronto ? t("gr.confrontoPronto") : t("gr.confrontoNonPronto"))}</strong>
        <span>${esc(pronto ? n(trovate.length, "gr.corrispondenze")
          : t("gr.daVerificareAncora", { n: barriera.pending_source_ids.length }))}</span>
      </div>
      ${trovate.length ? `<div class="lista" style="margin-top:16px">
        ${trovate.map((voce) => `<div class="voce">
          <span class="voce-capo">
            <span class="ruolo tipo-${esc(voce.node_type)}"><i aria-hidden="true"></i>${esc(root.etichettaTipo(voce.node_type))}</span>
            <strong>${esc(voce.label)}</strong></span>
          <span class="voce-meta">${esc(t("gr.presenteIn", { n: voce.occurrences.map((o) => o.source_name).join(" · ") }))}</span>
        </div>`).join("")}</div>` : ""}
      <p class="voce-meta" style="margin-top:16px">${esc(t("gr.multilingua"))}</p>
    </div>`;
  };

  const recordLabels = { indicators: "Sintomi e codici", failure: "Guasto", actions: "Azioni", inspection_steps: "Ispezioni ordinate", conditions: "Condizioni", affected_component: "Componente", name: "Nome", description: "Descrizione", instruction_text: "Istruzione", text: "Condizione", claim_evidence: "Prove della dichiarazione", failure_link_evidence: "Prove del collegamento al guasto", resolution_link_evidence: "Prove del rimedio", affects_link_evidence: "Prove del componente", quote: "Citazione esatta", source_anchor: "Fonte", source_page: "Pagina", step_index: "Indice del passo (da zero)", applies_to: "Si applica a", severity: "Gravità", code: "Codice", category: "Categoria", material_context: "Contesto materiale", action_kind: "Tipo di azione", kind: "Tipo", resolution_status: "Disposizione" };
  const editRecordFields = (value, path, sources) => {
    const key = path[path.length - 1];
    if (["record_window_id", "allowed_source_anchors", "record_anchor", "branch_anchor"].includes(key)) return "";
    if (Array.isArray(value)) return `<fieldset><legend>${esc(recordLabels[key] || key)}</legend>${value.map((v, i) => `<details open><summary>${i + 1}</summary>${editRecordFields(v, [...path, i], sources)}<button type="button" data-remove-record-field="${esc(JSON.stringify([...path, i]))}">Rimuovi voce</button></details>`).join("")}<button type="button" data-add-record-field="${esc(JSON.stringify(path))}">Aggiungi voce</button></fieldset>`;
    if (value && typeof value === "object") return `<fieldset><legend>${esc(recordLabels[key] || "Dichiarazione")}</legend>${Object.entries(value).map(([k, v]) => editRecordFields(v, [...path, k], sources)).join("")}${["failure", "affected_component"].includes(key) ? `<button type="button" data-remove-record-field="${esc(JSON.stringify(path))}">Rimuovi dichiarazione</button>` : ""}</fieldset>`;
    if (value === null && ["failure", "affected_component"].includes(key)) return `<p>${esc(recordLabels[key])}: non dichiarato nella proposta <button type="button" data-add-record-field="${esc(JSON.stringify(path))}">Aggiungi con prova</button></p>`;
    const data = `data-record-field="${esc(JSON.stringify(path))}" data-value-type="${value === null ? "nullable" : typeof value}"`;
    if (key === "source_anchor") return `<label>${esc(recordLabels[key])}<select ${data}>${sources.map((s) => `<option value="${esc(s.evidence_id)}" ${s.evidence_id === value ? "selected" : ""}>${esc(s.label)} — ${esc(s.excerpt.slice(0, 100))}</option>`).join("")}${sources.some((s) => s.evidence_id === value) ? "" : `<option selected value="${esc(value)}">${esc(value)}</option>`}</select></label>`;
    const options = { resolution_status: ["action_stated", "check_only", "no_action_stated", "ambiguous", "not_diagnostic"], applies_to: ["branch", "action", "inspection"], severity: ["", "Unknown", "Low", "Medium", "High", "Critical"], kind: ["symptom", "error_code"] }[key];
    if (options) return `<label>${esc(recordLabels[key])}<select ${data}>${options.map((v) => `<option value="${v}" ${v === (value || "") ? "selected" : ""}>${v || "Non dichiarato"}</option>`).join("")}</select></label>`;
    return `<label style="display:block">${esc(recordLabels[key] || key)}<textarea ${data} rows="2" style="width:100%">${esc(value == null ? "" : String(value))}</textarea></label>`;
  };
  const initialRecordCandidate = (r) => r.candidate || {
    record_window_id: r.record_window_id || "", allowed_source_anchors: [],
    record_anchor: r.record_anchor, branch_anchor: r.branch_anchor,
    indicators: [], failure: null, actions: [], inspection_steps: [], conditions: [],
    affected_component: null, resolution_status: "ambiguous",
  };
  const reviewGuidance = (record) => {
    const codes = new Set((record.drop_reasons || []).map((x) => x.code));
    if ([...codes].some((x) => /quote|anchor|page_mismatch/.test(x))) return "Controlla pagina, fonte e citazione: almeno una prova non corrisponde al documento. Copia il passaggio esatto dalla fonte affiancata.";
    if (codes.has("structurally_ambiguous_pairing")) return "La fonte contiene alternative: verifica quale causa corrisponde a ciascuna azione. Mantieni separati i rami e le loro condizioni; se il testo non decide, conserva lo stato ambiguo.";
    if (codes.has("compound_negative_condition_strengthened")) return "Controlla la condizione negativa: il NO a due verifiche congiunte non significa che entrambe siano negative.";
    if (codes.has("candidate_passage_missing_disposition")) return "Il passaggio non ha una proposta. Inserisci solo le dichiarazioni esplicite nella fonte, oppure indica che non è diagnostico.";
    if (codes.has("relation_endpoint_support_unestablished")) return "Le prove non stabiliscono ancora il collegamento. Cerca il titolo, la riga o il passaggio che associa esplicitamente sintomo, causa e rimedio.";
    if (codes.has("missing_failure") || codes.has("failure_inferred_from_instruction")) return "Verifica se la causa è dichiarata. Una richiesta di controllo o sostituzione da sola non dimostra un guasto; conserva la lacuna quando la causa manca.";
    return record.disposition === "publish" ? "Il record supera i controlli automatici. Verifica anche condizioni, ordine e completezza rispetto alla fonte." : "Confronta dichiarazioni, condizioni e istruzioni con la fonte. Mantieni le informazioni non dichiarate come lacune.";
  };
  const revisioneRecord = (modello) => {
    const g = modello.grafo;
    const records = (g.diagnostic_compilation_ledger || {}).records || [];
    const r = records.find((x) => x.branch_lineage_id === state.reviewBranch) || records.find((x) => x.disposition === "review") || records[0];
    const title = (x) => (x.candidate?.failure || {}).name || (x.candidate?.indicators?.[0] || {}).name || "Passaggio senza proposta";
    const sources = r ? g.evidence.filter((e) => (r.evidence_ids || []).includes(e.evidence_id)) : [];
    return `<div class="lavoro-pad record-review"><h3>Correzione di un record</h3>
      <p>Confronta ogni dichiarazione con la fonte. Il salvataggio crea una nuova revisione e ripete i controlli. I blocchi residui restano attivi.</p>
      <label>Record da correggere<select data-review-record style="width:100%">${records.map((x, i) => `<option value="${esc(x.branch_lineage_id)}" ${x === r ? "selected" : ""}>${i + 1}. ${esc(title(x))} · ${esc(x.disposition)}</option>`).join("")}</select></label>
      ${r ? `<p>${esc(reviewGuidance(r))}</p><details><summary>Dettagli dei controlli</summary><p>${esc((r.drop_reasons || []).map((x) => x.message).join(" "))}</p></details>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:20px">
        <form data-record-correction="${esc(r.branch_lineage_id)}">
          <label>Revisore<input name="reviewer" required maxlength="160"></label>
          <label>Motivazione<textarea name="reason" required maxlength="2000"></textarea></label>
          <button type="submit" class="btn primario" ${state.graphBusy ? "disabled" : ""}>Salva e ricompila</button>
          ${editRecordFields((state.diagnosticDrafts || {})[`${g.source_subgraph_revision_id}:${r.branch_lineage_id}`] || initialRecordCandidate(r), [], g.evidence)}
        </form>
        <aside><h4>Fonti del record</h4>${sources.map((e) => `<details open><summary>${esc(e.label)}</summary><p style="white-space:pre-wrap">${esc(e.locator.quote || e.excerpt)}</p><button type="button" data-scegli="evidenza" data-id="${esc(e.evidence_id)}">Apri fonte</button></details>`).join("") || "Seleziona una fonte nei campi della dichiarazione."}</aside>
      </div>` : "Nessun record disponibile."}
      <h3>Cronologia delle correzioni</h3>${(g.diagnostic_review_history || []).map((h) => `<details><summary>${esc(h.created_at)} · ${esc(h.reviewer)}</summary><p>${esc(h.reason)}</p><p>${esc(h.before.disposition)} → ${esc(h.after.disposition)}</p></details>`).join("") || "Nessuna correzione registrata."}</div>`;
  };

  const readRecordForm = (form) => {
    const g = vistaFonte().subgraph;
    const branch = form.dataset.recordCorrection;
    const entry = g.diagnostic_compilation_ledger.records.find((r) => r.branch_lineage_id === branch);
    const key = `${g.source_subgraph_revision_id}:${branch}`;
    const candidate = JSON.parse(JSON.stringify((state.diagnosticDrafts || {})[key] || initialRecordCandidate(entry)));
    form.querySelectorAll("[data-record-field]").forEach((field) => {
      const path = JSON.parse(field.dataset.recordField);
      let target = candidate;
      path.slice(0, -1).forEach((part) => { target = target[part]; });
      const part = path[path.length - 1];
      target[part] = field.value === "" && (field.dataset.valueType === "nullable" || ["severity", "step_index"].includes(part)) ? null
        : ["source_page", "step_index"].includes(part) ? Number(field.value) : field.value;
    });
    state.diagnosticDrafts = { ...(state.diagnosticDrafts || {}), [key]: candidate };
    return candidate;
  };
  const editRecordList = (button, remove) => {
    const form = button.closest("form");
    const candidate = readRecordForm(form);
    const path = JSON.parse(remove ? button.dataset.removeRecordField : button.dataset.addRecordField);
    let target = candidate;
    path.slice(0, -1).forEach((part) => { target = target[part]; });
    const key = path[path.length - 1];
    if (remove) { if (Array.isArray(target)) target.splice(key, 1); else target[key] = null; }
    else {
      const source = vistaFonte().subgraph.evidence.find((e) => e.evidence_id === candidate.record_anchor);
      const span = { source_anchor: candidate.record_anchor, source_page: source?.locator.page || 1, quote: "" };
      const claim = { name: "", description: "", claim_evidence: [span] };
      const value = key.endsWith("evidence") ? span : {
        failure: { ...claim, material_context: null },
        affected_component: { ...claim, category: null, affects_link_evidence: [] },
        indicators: { ...claim, kind: "symptom", code: null, severity: "Unknown", failure_link_evidence: [] },
        actions: { ...claim, instruction_text: "", action_kind: null, resolution_link_evidence: [] },
        inspection_steps: { instruction_text: "", claim_evidence: [span] },
        conditions: { text: "", applies_to: "branch", step_index: null, claim_evidence: [span] },
      }[key];
      if (Array.isArray(target[key])) target[key].push(value); else target[key] = value;
    }
    const reviewer = form.elements.reviewer.value, reason = form.elements.reason.value;
    const html = editRecordFields(candidate, [], vistaFonte().subgraph.evidence);
    const fields = form.querySelector("fieldset");
    fields.outerHTML = html;
    form.elements.reviewer.value = reviewer; form.elements.reason.value = reason;
  };

  const contenuto = (vista, modello) => {
    if (state.view === "confronto") return confronto();
    if (!modello) {
      return `<div class="lavoro-pad"><div class="vuoto">
        <strong>${esc(t("gr.nonCostruito"))}</strong><p>${esc(t("gr.nonCostruitoTesto"))}</p></div></div>`;
    }
    if (state.view === "elementi") return tabellaElementi(modello);
    if (state.view === "collegamenti") return tabellaCollegamenti(modello);
    if (state.view === "righe") return listaRighe(modello);
    if (state.view === "manca") return cosaManca(modello);
    if (state.view === "revisione") return revisioneRecord(modello);
    if (state.view === "catene") return catene(modello) + dettagliDiagnostici(modello);
    return mappa(modello);
  };

  /* ------------------------------------------------------ montaggio mappa */
  const smonta = () => { if (explorer) { explorer.distruggi(); explorer = null; } };

  const montaMappa = (contenitore, vista, modello) => {
    smonta();
    const ospite = contenitore.querySelector("[data-grafo]");
    if (!ospite || !modello) return;
    explorer = root.creaExplorer(ospite, {
      chiaveFonte: vista.source_id,
      nodi: modello.nodi.map((nodo) => ({
        id: nodo.node_id, tipo: nodo.node_type, etichetta: nodo.label,
        occorrenze: nodo.evidence_ids.length,
        lacuna: modello.lacunePerNodo.has(nodo.node_id),
        difetto: modello.difettiPerNodo.has(nodo.node_id),
      })),
      archi: modello.legami.map((legame) => ({
        id: legame.relation_id, da: legame.from_id, a: legame.to_id,
        etichettaTipo: root.etichettaRelazione(legame.relation_type),
      })),
    }, {
      descrizione: t("gr.mappaDi", { n: modello.nodi.length, c: modello.legami.length }),
      etichettaTipo: root.etichettaTipo,
      testoOccorrenze: (quante) => n(
        quante,
        modello.grafo.source_kind === "pdf" ? "isp.evidenzeLette" : "isp.righeLette",
      ),
      selezione: () => state.selection,
      onSelezione: (genere, id) => root.applicaSelezione(genere, id),
      onZoom: (k) => {
        const etichetta = contenitore.querySelector("[data-zoom-valore]");
        if (etichetta) etichetta.textContent = `${Math.round(k * 100)}%`;
      },
    });
    explorer.evidenzia(state.selection);
  };

  const ridisegnaContenuto = () => {
    const contenitore = root.appElement.querySelector('[data-regione="lavoro"] .lavoro-scorri');
    if (!contenitore) { root.render({ regioni: ["lavoro"] }); return; }
    const vista = vistaFonte();
    const modello = modelloDi(vista);
    smonta();
    root.paint(contenitore, contenuto(vista, modello));
    if (state.view === "mappa") montaMappa(contenitore, vista, modello);
  };

  /* ---------------------------------------------------------------- fase */
  root.phases.graph = {
    mostraIspettore: true,
    carica,

    titolo() {
      const vista = vistaFonte();
      if (state.view === "confronto") return { titolo: t("gr.confronto"), chips: "" };
      if (!vista) return { titolo: t("fase.graph"), chips: "" };
      const grafo = vista.subgraph;
      const tono = vista.state === "approved" ? "ok" : vista.state === "rejected" ? "errore" : "attesa";
      const chips = [
        `<span class="chip ${tono}">${esc(root.etichettaStato(vista.state))}</span>`,
        grafo ? `<span class="chip"><b>${grafo.nodes.length}</b> ${esc(t("gr.vista.elementi").toLocaleLowerCase())}</span>` : "",
        grafo ? `<span class="chip"><b>${grafo.relations.length}</b> ${esc(t("gr.vista.collegamenti").toLocaleLowerCase())}</span>` : "",
        chipAmbitoPdf(grafo),
      ].filter(Boolean).join("");
      return { titolo: vista.source_name, chips };
    },

    navExtra() {
      if (!state.graph) return "";
      const barriera = state.graph.merge_barrier;
      const pronto = barriera.state === "ready";
      return `<button type="button" class="nav-item ${state.view === "confronto" ? "active" : ""}" data-confronto>
        <span class="nav-sigla" aria-hidden="true">⋈</span>
        <span class="nav-label">${esc(t("gr.confronto"))}</span>
        <span class="nav-meta">${pronto ? (barriera.exact_matches || []).length : "—"}</span>
      </button>`;
    },

    bindNav(contenitore) {
      root.delegate(contenitore, "click", "[data-confronto]", () => {
        state.view = "confronto";
        root.clearSelection();
        root.render();
      });
    },

    renderLavoro() {
      if (!state.workspace || state.graphLoading) {
        return `<div class="stato-pagina"><strong>${esc(t("gr.carico"))}</strong><p>${esc(t("gr.caricoTesto"))}</p></div>`;
      }
      if (state.graphError && !state.graph) {
        return `<div class="stato-pagina"><strong>${esc(t("gr.erroreTitolo"))}</strong>
          <p role="alert">${esc(state.graphError)}</p>
          <button type="button" class="btn primario" data-riprova>${esc(t("ui.riprova"))}</button></div>`;
      }
      if (!state.graph || !state.graph.sources.length) {
        return `<div class="stato-pagina"><strong>${esc(t("gr.nessunaFonte"))}</strong><p>${esc(t("gr.nessunaFonteTesto"))}</p></div>`;
      }
      const vista = vistaFonte();
      const modello = modelloDi(vista);
      if (vista && vista.state === "deferred") {
        return `<div class="lavoro-pad"><section class="deferred-card">
          <span class="deferred-icon" aria-hidden="true">PDF</span>
          <div><strong>${esc(t("gr.pdfDifferito"))}</strong><p>${esc(t("gr.pdfDifferitoTesto"))}</p></div>
        </section></div>`;
      }
      const testa = state.view === "confronto" ? "" : `
        <div class="intestazione-lavoro"><p>${esc(vista && vista.subgraph
          ? t(vista.source_kind === "pdf" ? "gr.sottoPdf" : "gr.sotto")
          : t("gr.nonCostruito"))}</p></div>`;
      return `${testa}
        ${vista && !["confronto", "revisione"].includes(state.view) ? riepilogoPdf(vista.subgraph) : ""}
        ${modello && state.view !== "confronto" ? barra(modello) : ""}
        <div class="lavoro-scorri">${contenuto(vista, modello)}</div>`;
    },

    bindLavoro(contenitore) {
      root.delegate(contenitore, "change", "[data-review-record]", (select) => {
        const form = contenitore.querySelector("[data-record-correction]");
        if (form) readRecordForm(form);
        state.reviewBranch = select.value;
        root.render({ regioni: ["lavoro"] });
      });
      root.delegate(contenitore, "click", "[data-add-record-field]", (button) => editRecordList(button, false));
      root.delegate(contenitore, "click", "[data-remove-record-field]", (button) => editRecordList(button, true));
      root.delegate(contenitore, "submit", "[data-record-correction]", (form, event) => {
        event.preventDefault();
        if (state.graphBusy || !form.reportValidity()) return;
        const vista = vistaFonte();
        const branch = form.dataset.recordCorrection;
        const candidate = readRecordForm(form);
        if (candidate.resolution_status === "not_diagnostic") Object.assign(candidate, { indicators: [], failure: null, actions: [], inspection_steps: [], conditions: [], affected_component: null });
        esegui(async () => {
          const result = await root.api(`/api/g3/subgraphs/${encodeURIComponent(vista.subgraph.source_subgraph_revision_id)}/records/${encodeURIComponent(branch)}/correction`,
            { method: "POST", body: { candidate, reviewer: form.elements.reviewer.value, reason: form.elements.reason.value } });
          const graph = result.sources.find((x) => x.source_id === vista.source_id)?.subgraph;
          state.reviewBranch = graph?.diagnostic_review_history?.at(-1)?.after?.branch_lineage_id || branch;
          return result;
        });
      });
      root.delegate(contenitore, "click", "[data-riprova]", () => esegui(async () => {
        await carica();
        if (!state.graph) throw new Error(state.graphError || t("gr.erroreTitolo"));
        return state.graph;
      }));
      root.delegate(contenitore, "click", "[data-vista]", (elemento) => {
        state.view = elemento.dataset.vista;
        root.render({ regioni: ["lavoro"] });
      });
      root.delegate(contenitore, "click", "[data-scegli]", (elemento) => {
        root.applicaSelezione(elemento.dataset.scegli, elemento.dataset.id);
      });
      root.delegate(contenitore, "click", "[data-azzera]", () => {
        state.filters = { query: "", nodeType: "all", relationType: "all", onlyGaps: false, focus: false };
        root.render({ regioni: ["lavoro"] });
      });
      root.delegate(contenitore, "change", "[data-filtro]", (elemento) => {
        const chiave = elemento.dataset.filtro;
        state.filters[chiave] = elemento.type === "checkbox" ? elemento.checked : elemento.value;
        ridisegnaContenuto();
      });
      root.delegate(contenitore, "change", "[data-proiezione]", (elemento) => {
        state.graphProjection = elemento.value;
        root.clearSelection();
        state.filters.nodeType = "all";
        state.filters.relationType = "all";
        root.render({ regioni: ["lavoro", "ispettore"] });
      });
      root.delegate(contenitore, "click", "[data-zoom]", (elemento) => {
        if (!explorer) return;
        const azione = elemento.dataset.zoom;
        if (azione === "adatta") explorer.inquadra();
        else explorer.zoom(azione === "piu" ? 1.25 : 1 / 1.25);
      });
      root.delegate(contenitore, "click", "[data-ridisponi]", () => { if (explorer) explorer.ridisponi(); });
      const cerca = contenitore.querySelector("[data-cerca]");
      if (cerca) {
        cerca.addEventListener("input", () => {
          window.clearTimeout(cercaTimer);
          cercaTimer = window.setTimeout(() => {
            state.filters.query = cerca.value;
            ridisegnaContenuto();
          }, 180);
        });
      }
    },

    dopoLavoro(contenitore) {
      const scorri = contenitore.querySelector(".lavoro-scorri");
      if (state.view !== "mappa" || !scorri) { smonta(); return; }
      const vista = vistaFonte();
      montaMappa(scorri, vista, modelloDi(vista));
    },

    /* Selezionare non ricostruisce la mappa: cambia solo le classi. */
    suSelezione() {
      if (state.view === "mappa" && explorer) explorer.evidenzia(state.selection);
      else ridisegnaContenuto();
    },

    renderIspettore() {
      if (state.view === "confronto") {
        return `<div class="ispettore-vuoto"><strong>${esc(t("gr.confronto"))}</strong>
          <p>${esc(t("gr.confrontoNonModifica"))}</p></div>`;
      }
      const vista = vistaFonte();
      return root.renderIspettoreGrafo(vista, modelloDi(vista) || {
        nodiPerId: new Map(), evidenzePerId: new Map(), legamiPerNodo: new Map(),
        lacunePerNodo: new Map(), lacunePerEvidenza: new Map(), difettiPerNodo: new Map(),
      });
    },

    bindIspettore(contenitore) { root.bindIspettoreGrafo(contenitore); },

    renderDecisione() {
      if (!state.graph || state.view === "confronto") return "";
      const vista = vistaFonte();
      if (!vista) return "";
      const grafo = vista.subgraph;
      const occupato = state.graphBusy ? "disabled" : "";
      const errore = state.graphError ? `<p class="campo-errore" role="alert">${esc(state.graphError)}</p>` : "";

      if (state.rejectingSourceId === vista.source_id) {
        return `<form class="decisione-nota" data-nota>
          <label class="campo"><span>${esc(t("dec.cosaCorreggere"))}</span>
            <textarea name="note" required minlength="3" placeholder="${esc(t("dec.notaP"))}"></textarea></label>
          <div class="decisione-nota-azioni">
            <button type="submit" class="btn primario" ${occupato}>${esc(t("dec.registra"))}</button>
            <button type="button" class="btn quieto" data-annulla-nota>${esc(t("ui.annulla"))}</button>
          </div>${errore}</form>`;
      }

      const riga = (titolo, testo, azioni, ostacoli) => `
        <div class="decisione-riga">
          <div class="decisione-testo" aria-live="polite"><strong>${esc(titolo)}</strong><span>${esc(testo)}</span></div>
          ${ostacoli || ""}${azioni ? `<div class="decisione-azioni">${azioni}</div>` : ""}
        </div>${errore}`;

      if (vista.state === "waiting") {
        if (vista.source_kind === "pdf") {
          return riga(t("gr.pdfPreparazione"), vista.message, "");
        }
        return riga(t("dec.strutturaNonConfermata"), vista.message,
          `<button type="button" class="btn secondario" data-vai="structure">${esc(t("dec.vaiStruttura"))}</button>`);
      }
      if (vista.state === "deferred") {
        return riga(t("gr.pdfNessunaAzione"), t("gr.pdfNessunaAzioneTesto"), "");
      }
      if (!grafo) {
        return riga(t("gr.nonCostruitoTitolo"), t(vista.source_kind === "pdf" ? "gr.pdfNonCostruitoTesto" : "gr.nonCostruitoTesto"),
          `<button type="button" class="btn primario" data-costruisci ${occupato}>${esc(state.graphBusy ? t("gr.costruendo") : t("gr.costruisci"))}</button>`);
      }
      if (vista.state === "approved") return riga(t("dec.verificata"), t("dec.garanzia"), "");
      if (vista.state === "rejected") {
        const azione = vista.source_kind === "pdf"
          ? `<button type="button" class="btn primario" data-vai="documents">${esc(t("dec.gestisciDocumento"))}</button>`
          : `<button type="button" class="btn primario" data-vai="structure">${esc(t("dec.rivediStruttura"))}</button>`;
        return riga(
          t("dec.segnalata"),
          grafo.decision_note || t("dec.segnalazioneRegistrata"),
          azione
        );
      }

      const lacune = (grafo.knowledge_gaps || []).length;
      const difetti = (((grafo.validation || {}).issues) || []).length;
      const ostacoli = `<div class="ostacoli">
        ${lacune ? `<button type="button" class="ostacolo lacuna" data-vista="manca">${esc(n(lacune, "dec.lacuneNeiDati"))}</button>` : ""}
        ${difetti ? `<button type="button" class="ostacolo difetto" data-vista="manca">${esc(n(difetti, "dec.difettiTecnici"))}</button>` : ""}
      </div>`;
      const azioni = `
        <button type="button" class="btn pericolo" data-segnala ${occupato}>${esc(t("dec.segnala"))}</button>
        <button type="button" class="btn primario" data-approva ${grafo.approval_eligible ? occupato : "disabled"}>${esc(t("dec.conferma"))}</button>`;
      return riga(
        grafo.approval_eligible ? t("dec.domanda") : t("dec.nonVerificabile"),
        grafo.approval_eligible ? t("dec.garanzia") : t("dec.nonVerificabileTesto"),
        azioni,
        grafo.approval_eligible ? "" : ostacoli
      );
    },

    bindDecisione(contenitore) {
      root.delegate(contenitore, "click", "[data-costruisci]", () => {
        const vista = vistaFonte();
        esegui(() => root.api(
          `/api/workspaces/${encodeURIComponent(wsId())}/g3/sources/${encodeURIComponent(vista.source_id)}/generate`,
          { method: "POST" }
        ));
      });
      root.delegate(contenitore, "click", "[data-approva]", () => {
        const vista = vistaFonte();
        esegui(() => root.api(
          `/api/g3/subgraphs/${encodeURIComponent(vista.subgraph.source_subgraph_revision_id)}/decision`,
          { method: "POST", body: { action: "approve", note: null } }
        ));
      });
      root.delegate(contenitore, "click", "[data-segnala]", () => {
        state.rejectingSourceId = (vistaFonte() || {}).source_id || "";
        root.render({ regioni: ["decisione"] });
        contenitore.querySelector("textarea")?.focus();
      });
      root.delegate(contenitore, "click", "[data-annulla-nota]", () => {
        state.rejectingSourceId = "";
        root.render({ regioni: ["decisione"] });
      });
      root.delegate(contenitore, "click", "[data-vista]", (elemento) => {
        state.view = elemento.dataset.vista;
        root.render({ regioni: ["lavoro"] });
      });
      root.delegate(contenitore, "click", "[data-vai]", (elemento) => root.vaiAllaFase(elemento.dataset.vai));
      root.delegate(contenitore, "submit", "[data-nota]", (modulo, evento) => {
        evento.preventDefault();
        const nota = String(new FormData(modulo).get("note") || "").trim();
        if (!nota) return;
        const vista = vistaFonte();
        state.rejectingSourceId = "";
        esegui(() => root.api(
          `/api/g3/subgraphs/${encodeURIComponent(vista.subgraph.source_subgraph_revision_id)}/decision`,
          { method: "POST", body: { action: "reject", note: nota } }
        ));
      });
    },
  };

  /* ==========================================================================
     Il sottografo di una fonte, come superficie riusabile.

     Lo stesso grafo si guarda da due posti: il secondo passo dentro la fonte,
     dove il lavoro su quel file si chiude, e la fase del grafo, finché resta.
     Una sola implementazione — modello, mappa, decisione — esposta qui; chi
     la usa decide solo dove metterla e con quali parole.
     ====================================================================== */
  root.sottografo = {
    carica,
    smonta,
    vista: (sourceId) => (state.graph
      ? state.graph.sources.find((v) => v.source_id === sourceId) || null : null),
    modello: modelloDi,
    mappa,
    ambito: (vista) => riepilogoPdf(vista && vista.subgraph),
    chipAmbito: chipAmbitoPdf,
    monta: montaMappa,

    /** Vero se la mappa è a schermo e ha assorbito la selezione da sola. */
    evidenzia(selezione) {
      if (!explorer) return false;
      explorer.evidenzia(selezione);
      return true;
    },

    /**
     * Ridisegna solo la mappa, non la pagina.
     *
     * I filtri stanno nella striscia sopra l'area che scorre: rifare tutto
     * significherebbe rifare anche loro, e chi sta scrivendo nella casella di
     * ricerca perderebbe il fuoco a ogni lettera.
     */
    ridisegna(contenitore) {
      const scorri = (contenitore || root.appElement).querySelector(".lavoro-scorri");
      const fonte = root.fonteAttiva();
      const vista = fonte ? root.sottografo.vista(fonte.source_id) : null;
      if (!scorri || !vista || !vista.subgraph) { root.render({ regioni: ["lavoro"] }); return; }
      const modello = modelloDi(vista);
      smonta();
      root.paint(scorri, mappa(modello));
      montaMappa(scorri, vista, modello);
    },

    /** I comandi che vivono sopra e dentro la mappa. */
    bindMappa(contenitore) {
      const ridisegna = () => root.sottografo.ridisegna(contenitore);
      root.delegate(contenitore, "click", "[data-scegli]", (elemento) => {
        root.applicaSelezione(elemento.dataset.scegli, elemento.dataset.id);
      });
      root.delegate(contenitore, "click", "[data-azzera]", () => {
        state.filters = { query: "", nodeType: "all", relationType: "all", onlyGaps: false, focus: false };
        root.render({ regioni: ["lavoro"] });
      });
      root.delegate(contenitore, "change", "[data-filtro]", (elemento) => {
        const chiave = elemento.dataset.filtro;
        state.filters[chiave] = elemento.type === "checkbox" ? elemento.checked : elemento.value;
        ridisegna();
      });
      root.delegate(contenitore, "click", "[data-zoom]", (elemento) => {
        if (!explorer) return;
        const azione = elemento.dataset.zoom;
        if (azione === "adatta") explorer.inquadra();
        else explorer.zoom(azione === "piu" ? 1.25 : 1 / 1.25);
      });
      root.delegate(contenitore, "click", "[data-ridisponi]", () => { if (explorer) explorer.ridisponi(); });
      const cerca = contenitore.querySelector("[data-cerca]");
      if (cerca && !cerca.dataset.legato) {
        cerca.dataset.legato = "1";
        cerca.addEventListener("input", () => {
          window.clearTimeout(cercaTimer);
          cercaTimer = window.setTimeout(() => {
            state.filters.query = cerca.value;
            ridisegna();
          }, 180);
        });
      }
    },

    /**
     * Che cosa deve fare l'operatore, dentro la fonte, su questo grafo.
     *
     * Una riga sola, in fondo alla pagina, dove sta ogni decisione di questo
     * applicativo: a sinistra perché, a destra il tasto. Mai più di un tasto
     * principale per volta.
     */
    decisione(vista, fonte) {
      const occupato = state.graphBusy ? "disabled" : "";
      const errore = state.graphError ? `<p class="campo-errore" role="alert">${esc(state.graphError)}</p>` : "";
      const riga = (titolo, testo, azioni, ostacoli) => `
        <div class="decisione-riga">
          <div class="decisione-testo" aria-live="polite"><strong>${esc(titolo)}</strong><span>${esc(testo)}</span></div>
          ${ostacoli || ""}${azioni ? `<div class="decisione-azioni">${azioni}</div>` : ""}
        </div>${errore}`;

      if (vista && vista.state === "deferred") {
        return riga(t("gr.pdfNessunaAzione"), t("gr.pdfNessunaAzioneTesto"), "");
      }
      if (!vista || vista.state === "waiting") {
        if (fonte.source_kind === "pdf") {
          return riga(t("gr.pdfPreparazione"), t("gr.pdfPreparazioneTesto"), "");
        }
        return riga(t("fon.nonConfermata"), t("fon.nonConfermataTesto"),
          `<button type="button" class="btn primario" data-passo="lettura">${esc(t("fon.tornaLettura"))}</button>`);
      }
      const grafo = vista.subgraph;
      if (!grafo) {
        const voce = root.journeySource ? root.journeySource(vista.source_id) : null;
        const rifatto = voce && voce.graph_revision_count > 0;
        const testo = rifatto
          ? (fonte.source_kind === "pdf" ? "fon.pdfRifareTesto" : "fon.rifareTesto")
          : (fonte.source_kind === "pdf" ? "fon.pdfDaCostruireTesto" : "fon.daCostruireTesto");
        return riga(
          t(rifatto ? "fon.rifare" : "fon.daCostruire"),
          t(testo),
          `<button type="button" class="btn primario" data-costruisci ${occupato}>${
            esc(state.graphBusy ? t("gr.costruendo") : t("gr.costruisci"))}</button>`
        );
      }
      if (state.rejectingSourceId === vista.source_id) {
        return `<form class="decisione-nota" data-nota>
          <label class="campo"><span>${esc(t("dec.cosaCorreggere"))}</span>
            <textarea name="note" required minlength="3" placeholder="${esc(t("dec.notaP"))}"></textarea></label>
          <div class="decisione-nota-azioni">
            <button type="submit" class="btn primario" ${occupato}>${esc(t("dec.registra"))}</button>
            <button type="button" class="btn quieto" data-annulla-nota>${esc(t("ui.annulla"))}</button>
          </div>${errore}</form>`;
      }
      if (vista.state === "approved") return riga(t("dec.verificata"), t("dec.garanzia"), "");
      if (vista.state === "rejected") {
        const azione = fonte.source_kind === "pdf"
          ? `<button type="button" class="btn primario" data-vai="documents">${esc(t("dec.gestisciDocumento"))}</button>`
          : `<button type="button" class="btn primario" data-passo="lettura">${esc(t("fon.tornaLettura"))}</button>`;
        return riga(t("dec.segnalata"), grafo.decision_note || t("dec.segnalazioneRegistrata"),
          azione);
      }
      const lacune = (grafo.knowledge_gaps || []).length;
      const difetti = (((grafo.validation || {}).issues) || []).length;
      /* Toccarli non porta altrove: riporta la colonna di destra alla
         panoramica, dove quegli stessi ostacoli sono elencati per esteso. */
      const ostacoli = `<div class="ostacoli">
        ${lacune ? `<button type="button" class="ostacolo lacuna" data-panoramica>${esc(n(lacune, "dec.lacuneNeiDati"))}</button>` : ""}
        ${difetti ? `<button type="button" class="ostacolo difetto" data-panoramica>${esc(n(difetti, "dec.difettiTecnici"))}</button>` : ""}
      </div>`;
      return riga(
        grafo.approval_eligible ? t("dec.domanda") : t("dec.nonVerificabile"),
        grafo.approval_eligible ? t("dec.garanzia") : t("dec.nonVerificabileTesto"),
        `<button type="button" class="btn pericolo" data-segnala ${occupato}>${esc(t("dec.segnala"))}</button>
         <button type="button" class="btn primario" data-approva ${grafo.approval_eligible ? occupato : "disabled"}>${esc(t("dec.conferma"))}</button>`,
        grafo.approval_eligible ? "" : ostacoli
      );
    },

    bindDecisione(contenitore, esecutore) {
      const corrente = () => {
        const fonte = root.fonteAttiva();
        return fonte ? root.sottografo.vista(fonte.source_id) : null;
      };
      root.delegate(contenitore, "click", "[data-costruisci]", () => {
        const vista = corrente();
        if (!vista) return;
        esecutore(() => root.api(
          `/api/workspaces/${encodeURIComponent(wsId())}/g3/sources/${encodeURIComponent(vista.source_id)}/generate`,
          { method: "POST" }
        ));
      });
      root.delegate(contenitore, "click", "[data-approva]", () => {
        const vista = corrente();
        if (!vista || !vista.subgraph) return;
        esecutore(() => root.api(
          `/api/g3/subgraphs/${encodeURIComponent(vista.subgraph.source_subgraph_revision_id)}/decision`,
          { method: "POST", body: { action: "approve", note: null } }
        ));
      });
      root.delegate(contenitore, "click", "[data-segnala]", () => {
        state.rejectingSourceId = (corrente() || {}).source_id || "";
        root.render({ regioni: ["decisione"] });
        contenitore.querySelector("textarea")?.focus();
      });
      root.delegate(contenitore, "click", "[data-annulla-nota]", () => {
        state.rejectingSourceId = "";
        root.render({ regioni: ["decisione"] });
      });
      root.delegate(contenitore, "click", "[data-panoramica]", () => {
        root.clearSelection();
        root.render({ regioni: ["ispettore"] });
      });
      root.delegate(contenitore, "click", "[data-vai]", (elemento) => {
        root.vaiAllaFase(elemento.dataset.vai);
      });
      root.delegate(contenitore, "submit", "[data-nota]", (modulo, evento) => {
        evento.preventDefault();
        const nota = String(new FormData(modulo).get("note") || "").trim();
        const vista = corrente();
        if (!nota || !vista || !vista.subgraph) return;
        state.rejectingSourceId = "";
        esecutore(() => root.api(
          `/api/g3/subgraphs/${encodeURIComponent(vista.subgraph.source_subgraph_revision_id)}/decision`,
          { method: "POST", body: { action: "reject", note: nota } }
        ));
      });
    },
  };
})();
